# DilSeSuno Bot
A Hinglish emotional support AI bot using Ollama + Vicuna 7B + Node.js.

## Setup
1. Install dependencies:
   ```
   npm install
   ```
2. Start the bot:
   ```
   npm start
   ```

## API
POST /chat
Body:
```json
{ "message": "Hi, how are you?" }
```